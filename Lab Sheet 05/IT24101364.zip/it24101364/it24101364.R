setwd("C:\\Users\\it24101364\\Desktop\\it24101364")
#Q1
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE,sep=",")
fix(Delivery_Times)
attach(Delivery_Times)

#Q2
X<-Delivery_Times[[1]]

histogram<-hist(X,main = "Histogram of Delivery Times",breaks = seq(20,70,length=10),right = TRUE)

#Q4

cum_freq <- cumsum(histogram$counts)
midpoints <- histogram$mids

plot(midpoints, cum_freq, type = "o", 
     main = "Cumulative Frequency Polygon (Ogive)", 
     xlab = "Delivery Time", 
     ylab = "Cumulative Frequency")