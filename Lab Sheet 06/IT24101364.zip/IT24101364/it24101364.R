setwd("C:\\Users\\it24101364\\Desktop\\IT24101364")

#Exercise

#01

#1
#Binomial Distribution
#2
pbinom(46,50,0.85,lower.tail = FALSE)

#02

#1
#Number of calls recived in given day
#2
#Poisson Distribution
#3
dpois(15,12)